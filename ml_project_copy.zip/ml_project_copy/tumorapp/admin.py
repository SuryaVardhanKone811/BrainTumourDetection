from django.contrib import admin
from tumorapp.models import tumor
# Register your models here.
admin.site.register(tumor)
