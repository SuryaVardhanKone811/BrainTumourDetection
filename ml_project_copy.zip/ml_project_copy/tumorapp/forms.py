from django import forms
from tumorapp.models import tumor

class UploadForm(forms.ModelForm):
    
    class Meta:
        model = tumor
        fields = ['image']


        